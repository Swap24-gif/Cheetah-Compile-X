// Netlify Function: /.netlify/functions/ai-review
// Keeps the Anthropic API key on the server. The browser never sees it.
//
// Required setup on Netlify:
//   Site settings -> Environment variables -> add ANTHROPIC_API_KEY = sk-ant-...
// Get a key from https://console.anthropic.com/settings/keys

exports.handler = async function (event) {
  if (event.httpMethod !== "POST") {
    return respond(405, { error: "Method not allowed. Use POST." });
  }

  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch {
    return respond(400, { error: "Invalid JSON body." });
  }

  const code = (body.code || "").toString();
  const language = (body.language || "code").toString().slice(0, 40);

  if (!code.trim()) {
    return respond(400, { error: "No code provided." });
  }
  if (code.length > 20000) {
    return respond(400, { error: "Code is too long to review (20,000 char limit)." });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return respond(500, {
      error: "Server is missing ANTHROPIC_API_KEY. Add it in Netlify: Site settings -> Environment variables."
    });
  }

  const prompt = `You are a precise senior code reviewer inside a developer tool called Cheetah Compile X. Review this ${language} code. Be direct and specific. Use exactly this format:

VERDICT: [one line summary]
BUGS: [real bugs found, or "none found"]
PERFORMANCE: [issues, or "no concerns"]
STYLE: [brief style notes]
SUGGESTION: [one concrete improvement, with a short code snippet if useful]

Code:
\`\`\`${language}
${code}
\`\`\``;

  try {
    const anthropicRes = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        messages: [{ role: "user", content: prompt }]
      })
    });

    const data = await anthropicRes.json();

    if (!anthropicRes.ok) {
      return respond(anthropicRes.status, {
        error: data?.error?.message || "Anthropic API returned an error."
      });
    }

    const text = (data.content || [])
      .filter((block) => block.type === "text")
      .map((block) => block.text)
      .join("");

    return respond(200, { text: text || "No response received." });
  } catch (err) {
    return respond(500, { error: "Failed to reach Anthropic API: " + err.message });
  }
};

function respond(statusCode, obj) {
  return {
    statusCode,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(obj)
  };
}
